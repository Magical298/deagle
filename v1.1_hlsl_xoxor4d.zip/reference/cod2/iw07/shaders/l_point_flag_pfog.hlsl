#define USE_SPECULAR	0
#define PRE_ALPHA_BLEND	0
#define USE_DETAIL		0
#define PIXEL_FOG

#include "lib/light_point_flag.hlsl"
