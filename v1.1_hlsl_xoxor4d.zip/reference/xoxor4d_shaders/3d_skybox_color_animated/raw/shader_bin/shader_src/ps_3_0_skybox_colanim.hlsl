#define PC
#define IS_VERTEX_SHADER 0
#define IS_PIXEL_SHADER 1
#include <shader_vars.h>

float4 ps_main( float3 worldPos : TEXCOORD ) : COLOR    // this is another way to use our vertex shader output semantics 
{
	float3 color = texCUBE(skyMapSampler, worldPos);
	color.r *= clamp(sin( gamegameTime.w * 3.0), 0.25, 1.0 );
	color.g *= clamp(cos( gamegameTime.w * 5.0), 0.5, 1.0 );
	
	return float4( color.xyz, 0.0f ); // alpha = 0.0; don´t ask me why .. but it works
}
