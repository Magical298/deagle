#define PC
#define IS_VERTEX_SHADER 1
#define IS_PIXEL_SHADER 0
#include <shader_vars.h>

#define ROTATESKY false // true to rotate the skybox

struct V_IN
{
	float4 position : POSITION;
};

struct V_OUT
{
	float4 position : POSITION;
	float3 worldPos : TEXCOORD;
};

float4x4 rotate(float3 r, float4 d) // r=rotations axes
{
    float cx, cy, cz, sx, sy, sz;
    sincos(r.x, sx, cx);
    sincos(r.y, sy, cy);
    sincos(r.z, sz, cz);	
    return float4x4( cy*cz,     -sz,    sy, d.x,
                     sz,      cx*cz,   -sx, d.y,
                    -sy,         sx, cx*cy, d.z,
                      0,          0,     0, d.w );	
}

V_OUT vs_main( V_IN input ) 
{
	V_OUT output = (V_OUT)0;

	float4 dir;
	dir.xyz = input.position - eyePos;
	dir.w = 0;	// we want the sky to be as far back as possible so we can never reach it

	if( ROTATESKY )	// this will rotate all verts around the world center ( 0,0,0 )
	{
		float4x4 rot_mat;
		//					defines the rotation axis
    	rot_mat = rotate(float3(0,0,gameTime.w),float4(0,0,0,1)); // first ROTAXIS

		float3 toOrigin = dir;
    	float3 rotatedVertex = mul(rot_mat, toOrigin);

		output.position = mul(float4( rotatedVertex, 1.0f), worldViewProjectionMatrix);
	}
	else
		output.position = mul(float4( dir ), worldViewProjectionMatrix);

	output.worldPos = dir;

	return output;
}
