#define PC
#define IS_VERTEX_SHADER 1
#define IS_PIXEL_SHADER 0
#include <shader_vars.h>

struct V_IN
{
    float3 position : POSITION;
    float2 texCoord : TEXCOORD;
};

struct V_OUT
{
    float4 position : POSITION;
    float2 texCoord : TEXCOORD0;
};

V_OUT vs_main( V_IN input ) 
{
    V_OUT output = (V_OUT)0;

    output.position = mul(float4(input.position.xyz, 1.0f), worldViewProjectionMatrix);
    output.texCoord = input.texCoord;

    return output;
}
