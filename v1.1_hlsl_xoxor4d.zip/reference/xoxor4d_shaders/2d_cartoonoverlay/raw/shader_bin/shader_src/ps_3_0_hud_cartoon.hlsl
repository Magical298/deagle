// MATERIAL TYPE BLEND

#define PC
#define IS_VERTEX_SHADER 0
#define IS_PIXEL_SHADER 1
#include <shader_vars.h>

#define nColors 8.0
#define LINES 1.5

float3 Outline(float2 uv)
{
  	float4 lines= float4(0.30, 0.59, 0.11, 1.0);

	lines.rgb = lines.rgb * LINES;

  	float s11 = dot(tex2D(colorMapSampler, uv + float2(-1.0 / renderTargetSize.x, -1.0 / renderTargetSize.y)), lines);   // LEFT
  	float s12 = dot(tex2D(colorMapSampler, uv + float2(0, -1.0 / renderTargetSize.y)), lines);             // MIDDLE
  	float s13 = dot(tex2D(colorMapSampler, uv + float2(1.0 / renderTargetSize.x, -1.0 / renderTargetSize.y)), lines);    // RIGHT
 

  	float s21 = dot(tex2D(colorMapSampler, uv + float2(-1.0 / renderTargetSize.x, 0.0)), lines);                // LEFT
  	// Omit center
  	float s23 = dot(tex2D(colorMapSampler, uv + float2(-1.0 / renderTargetSize.x, 0.0)), lines);                // RIGHT
 
  	float s31 = dot(tex2D(colorMapSampler, uv + float2(-1.0 / renderTargetSize.x, 1.0 / renderTargetSize.y)), lines);    // LEFT
  	float s32 = dot(tex2D(colorMapSampler, uv + float2(0, 1.0 / renderTargetSize.y)), lines);              // MIDDLE
  	float s33 = dot(tex2D(colorMapSampler, uv + float2(1.0 / renderTargetSize.x, 1.0 / renderTargetSize.y)), lines); // RIGHT
 
  	float t1 = s13 + s33 + (2.0 * s23) - s11 - (2.0 * s21) - s31;
  	float t2 = s31 + (2.0 * s32) + s33 - s11 - (2.0 * s12) - s13;
 
  	float3 col;
 
	if (((t1 * t1) + (t2* t2)) > 0.04) 
  		col = float3(-1.,-1.,-1.);
	else
    	col = float3(0.,0.,0.);
 
  	return col;
}

float3 lerp(float3 colorone, float3 colortwo, float value)
{
	return (colorone + value*(colortwo-colorone));
} 

float3 RGBToHSV( float3 RGB )
{
    
    float4 k = float4(0.0, -1.0/3.0, 2.0/3.0, -1.0);
    float4 p = RGB.g < RGB.b ? float4(RGB.b, RGB.g, k.w, k.z) : float4(RGB.gb, k.xy);
    float4 q = RGB.r < p.x   ? float4(p.x, p.y, p.w, RGB.r) : float4(RGB.r, p.yzx);
    float d = q.x - min(q.w, q.y);
    float e = 1.0e-10;
    return float3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
}

float3 HSVToRGB( float3 HSV )
{
    
    float4 k = float4( 1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0 );
    float3 p = abs(fract(HSV.xxx + k.xyz) * 6.0 - k.www);
    return HSV.z * lerp(k.xxx, clamp(p - k.xxx, 0.0, 1.0), HSV.y);
}

float4 ps_main( float2 uv : TEXCOORD0 ) : COLOR
{
   	float3 col;
    float  cutColor;
    float2 target_c;

    col = tex2D( colorMapSampler, uv ).rgb;
    cutColor = 1.0 / nColors;

    col = RGBToHSV( col );
    target_c = cutColor * floor( col.gb / cutColor );
    col = HSVToRGB(float3( col.r, target_c ));

    return float4( col + Outline(uv), 1.0 );
}