#define PC
#define IS_VERTEX_SHADER 1
#define IS_PIXEL_SHADER 0
#include <shader_vars.h>

struct V_IN
{
    float3 position : POSITION;
    float2 tc       : TEXCOORD;
};

struct V_OUT
{
    float4 position : POSITION;
    float3 TexCoordX : TEXCOORD0;
    float3 TexCoordY : TEXCOORD1;
};

V_OUT vs_main( V_IN input ) 
{
    V_OUT output = (V_OUT)0;

    float3 ConvergeX = float3(-2.0f, 0.0f, 2.0f);
    float3 ConvergeY = float3(-2.0f, 0.0f, 2.0f);
    float3 RadialConvergeX = float3(-1.0f, 0.0f, 1.0f);
    float3 RadialConvergeY = float3(-1.0f, 0.0f, 1.0f);

    output.position = mul(float4(input.position.x, input.position.y, input.position.z, 1.0f), worldViewProjectionMatrix); // z does nothing // w = scale on hud 1.0 = fullscreen; more = smaller to left upper
    //output.position.xy -= 0.5f; // center
    //output.position.xy *= 2.0f; // zoom

    float2 TexCoord = input.tc;

    // imaginary texel dimensions independed from screen dimension, but ratio
    float2 TexelDims = (1.0f / 512);
    output.TexCoordX = TexCoord.xxx;
    output.TexCoordY = TexCoord.yyy;

    // center coordinates
    output.TexCoordX -= 0.5f;
    output.TexCoordY -= 0.5f;

    // radial converge offset to "translate" the most outer pixel as thay would be translated by the linar converge with the same amount
    float2 radialConvergeOffset = 2.0f;

    // radial converge
    output.TexCoordX *= 1.0f + RadialConvergeX * TexelDims.xxx * radialConvergeOffset.xxx;
    output.TexCoordY *= 1.0f + RadialConvergeY * TexelDims.yyy * radialConvergeOffset.yyy;

    // un-center coordinates
    output.TexCoordX += 0.5f;
    output.TexCoordY += 0.5f;

    // linear converge
    output.TexCoordX += ConvergeX * TexelDims.xxx;
    output.TexCoordY += ConvergeY * TexelDims.yyy;

    return output;
}
