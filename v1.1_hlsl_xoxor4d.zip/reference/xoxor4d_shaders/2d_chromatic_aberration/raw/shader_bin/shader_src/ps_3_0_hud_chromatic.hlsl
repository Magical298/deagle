#define PC
#define IS_VERTEX_SHADER 0
#define IS_PIXEL_SHADER 1
#include <shader_vars.h>

float4 ps_main( float3 TexCoordX : TEXCOORD0, float3 TexCoordY : TEXCOORD1, float2 uv : TEXCOORD2 ) : COLOR
{
    float r = tex2D(colorMapSampler, float2(TexCoordX.x, TexCoordY.x) ).x;
	float g = tex2D(colorMapSampler, float2(TexCoordX.y, TexCoordY.y) ).y;
	float b = tex2D(colorMapSampler, float2(TexCoordX.z, TexCoordY.z) ).z;

	return float4(r, g, b, 1.0f);
}
